# Databricks notebook source
spark.sql(f"""
           SELECT *,
           date(current_timestamp()) AS processed_date
           FROM `etl-catlog`.bronze.bronze_table
          """).createOrReplaceTempView('silver_view')

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE `etl-catlog`.silver.silver_table
# MAGIC AS
# MAGIC SELECT * FROM silver_view

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM `etl-catlog`.silver.silver_table

# COMMAND ----------

