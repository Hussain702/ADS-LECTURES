# Databricks notebook source
# MAGIC %md
# MAGIC **dim_customers**

# COMMAND ----------



spark.sql(f"""
   WITH rem_dup AS (
    SELECT
       DISTINCT customer_id,
        customer_name,
        customer_email
    FROM `etl-catlog`.silver.silver_table
   
)
SELECT *,
    row_number() OVER (ORDER BY product_id) AS DimCustomerSK
FROM rem_dup
""").createOrReplaceTempView("customer_source")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC
# MAGIC  FROM `etl-catlog`.gold.dim_customer

# COMMAND ----------

# MAGIC %md
# MAGIC dim_product

# COMMAND ----------


spark.sql(f"""
   WITH rem_dup AS (
    SELECT
       DISTINCT product_id,
        product_name,
        product_category
    FROM `etl-catlog`.silver.silver_table
   
)
SELECT *,
    row_number() OVER (ORDER BY product_id) AS DimProductSK
FROM rem_dup
""").createOrReplaceTempView("product_source")


# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM `etl-catlog`.gold.dim_product

# COMMAND ----------

if spark.catalog.tableExists("`etl-catlog`.gold.dim_product"):
    spark.sql(f"""
              MERGE INTO `etl-catlog`.gold.dim_product AS t
              USING product_source AS s
             ON s.product_id=t.product_id
             WHEN MATCHED THEN UPDATE SET *
             WHEN NOT MATCHED THEN INSERT *
             """)
else:
    spark.sql(f"""
              CREATE TABLE `etl-catlog`.gold.dim_product as
              SELECT * FROM product_source
              """)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM `etl-catlog`.gold.dim_product

# COMMAND ----------

# MAGIC %md
# MAGIC FACT_TABLE

# COMMAND ----------

spark.sql("""
           SELECT 
           c.DimCustomerSk,
           DimProductSk,
           f.unit_price,
           f.quantity
          FROM `etl-catlog`.silver.silver_table as f 
          LEFT JOIN `etl-catlog`.gold.dim_customer as c
          ON f.customer_id=c.customer_id
          LEFT JOIN `etl-catlog`.gold.dim_product as p 
          ON f.product_id=p.product_id 
           
           """).createOrReplaceTempView("fact_source")


# COMMAND ----------

# DBTITLE 1,* FR
# MAGIC %sql
# MAGIC SELECT * FROM fact_source

# COMMAND ----------

