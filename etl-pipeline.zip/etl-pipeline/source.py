# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE `etl-catlog`.default.source_data
# MAGIC AS
# MAGIC SELECT * FROM datamodelling.default.source_data

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM `etl-catlog`.default.source_data
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO `etl-catlog`.default.source_data
# MAGIC (order_id, order_date, customer_id, customer_name, customer_email, product_id, product_name, product_category, quantity, unit_price, payment_type, country, last_updated)
# MAGIC VALUES (1, '2024-01-13', 102, 'John Doe', 'john.doe@example.com', 202, 'Product A', 'Category X', 2, 10.00, 'Credit Card', 'USA', '2022-01-01')