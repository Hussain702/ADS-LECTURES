# Databricks notebook source
last_upload_date = spark.sql("select max(order_date) from `etl-catlog`.bronze.bronze_table").collect()[0][0]

# COMMAND ----------

last_upload_date

# COMMAND ----------

spark.sql(f"""
           SELECT * FROM `etl-catlog`.default.source_data
           WHERE order_date> '{last_upload_date}'
          
          """).createOrReplaceTempView('source_view')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM source_view

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE `etl-catlog`.bronze.bronze_table
# MAGIC AS
# MAGIC SELECT * FROM source_view

# COMMAND ----------

